#!/bin/bash
test_device="/dev/sdl1"
mp="/mnt/xfs"
echo "Hello"
bsctl -l | grep $test_device >> /dev/null; device_ex=$?
if [ $device_ex -ne 0 ]; then
	bsctl -a $test_device
fi

output=`bsctl -l | grep $test_device`
bsctl_output=($(echo $output))


#Filesystem           Device     Snapshot   Dirty    ChLog    Data     Metadata
#/dev/sda1            sda        -          Yes      No       No       No   

Device="${bsctl_output[1]}"
Snapshot="${bsctl_output[2]}"
Dirty="${bsctl_output[3]}"
ChLog="${bsctl_output[4]}"
Data="${bsctl_output[5]}"
Metadata="${bsctl_output[6]}"
rm -rf result.txt >> /dev/null

if [ $Snapshot != "-" ]; then
	bsctl -e $test_device
fi

if [ $Data != "Yes" ]; then
	bsctl --create-data-store $test_device >> /dev/null
	bsctl --map-data-store $test_device
fi

if [ $ChLog != "Yes" ]; then
	bsctl --create-chlog-store $test_device >> /dev/null
	bsctl --map-chlog-store $test_device
fi

if [ $Metadata != "Yes" ]; then
	bsctl --map-metadata-store $test_device >> /dev/null
fi

function clean_results ()
{
	rm -r ./result.txt >> /dev/null
	rm -r ./kmalloc* >> /dev/null
}

clean_results


for i in {1..20}; do
	cat /proc/slabinfo  | grep kmalloc-* >> result.txt
	bsctl -s $test_device >> /dev/null
	bsrw $test_device /dev/null &
	( dd if=/dev/zero of=$mp/image bs=1M count=40 ) > /dev/null 2>&1 &
	wait $(jobs -p)
	bsctl -e $test_device >> /dev/null 
	echo "" >> result.txt
	cat /proc/slabinfo  | grep kmalloc-* >> result.txt
	echo $i snapshot has been completed. >> result.txt
	echo "" >> result.txt
	echo "" >> result.txt
done
rm -rf $mp/image
bsctl -d $test_device

cat result.txt | egrep -E  ^kmalloc-32 | awk '{print $2}' | uniq >> kmalloc-32.txt
cat result.txt | egrep -E  ^kmalloc-64 | awk '{print $2}' | uniq >> kmalloc-64.txt
cat result.txt | egrep -E  ^kmalloc-128 | awk '{print $2}' | uniq  >> kmalloc-128.txt
cat result.txt | egrep -E  ^kmalloc-192 | awk '{print $2}' | uniq >> kmalloc-192.txt
cat result.txt | egrep -E  ^kmalloc-256 | awk '{print $2}' | uniq >> kmalloc-256.txt
cat result.txt | egrep -E  ^kmalloc-512 | awk '{print $2}' | uniq >> kmalloc-512.txt
cat result.txt | egrep -E  ^kmalloc-1024 | awk '{print $2}' | uniq >> kmalloc-1024.txt
cat result.txt | egrep -E  ^kmalloc-2048 | awk '{print $2}' | uniq >> kmalloc-2048.txt

function print_results ()
{
	for i in kmalloc-32.txt kmalloc-64.txt kmalloc-128.txt kmalloc-192.txt kmalloc-256.txt kmalloc-512.txt kmalloc-1024.txt kmalloc-2048.txt
	do
		echo "THE UNIQ OF $i"
		cat $i
		echo "THE UNIQ OF $i finished"
		echo ""
	done
}

print_results

exit 0
