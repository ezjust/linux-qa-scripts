#!/bin/bash
###
parted -s /dev/sdb mklabel msdos mkpart primary 2048s 100% set 1 raid on
parted -s /dev/sdc mklabel msdos mkpart primary 2048s 100% set 1 raid on
parted -s /dev/sdd mklabel msdos mkpart primary 2048s 100% set 1 raid on
parted -s /dev/sde mklabel msdos mkpart primary 2048s 100% set 1 raid on
parted -s /dev/sdf mklabel msdos mkpart primary 2048s 100% set 1 raid on
parted -s /dev/sdg mklabel msdos mkpart primary 2048s 100% set 1 raid on
parted -s /dev/sdh mklabel msdos mkpart primary 2048s 100% set 1 raid on
parted -s /dev/sdi mklabel msdos mkpart primary 2048s 100% set 1 raid on
parted -s /dev/sdj mklabel msdos mkpart primary 2048s 100% set 1 raid on
parted -s /dev/sdk mklabel msdos mkpart primary 2048s 100% set 1 raid on
parted -s /dev/sdl mklabel msdos mkpart primary 2048s 100% set 1 raid on
###
mdadm --create /dev/md0 --verbose --level=raid0 --raid-devices=2 /dev/sdb1 /dev/sdc1
mdadm --create /dev/md1 --verbose --level=raid1 --raid-devices=2 /dev/sdd1 /dev/sde1
mdadm --create /dev/md5 --verbose --level=raid5 --raid-devices=3 /dev/sdf1 /dev/sdg1 /dev/sdh1
mdadm --create /dev/md10 --verbose --level=raid10 --raid-devices=4 /dev/sdi1 /dev/sdj1 /dev/sdk1 /dev/sdl1
###
mkfs.ext3 /dev/md0
mkfs.xfs /dev/md1
mkfs.ext4 /dev/md5
mkfs.xfs /dev/md10
###
mkdir /mnt/raid0
mkdir /mnt/raid1
mkdir /mnt/raid5
mkdir /mnt/raid10
###
mount /dev/md0 /mnt/raid0
mount /dev/md1 /mnt/raid1
mount /dev/md5 /mnt/raid5
mount /dev/md10 /mnt/raid10
###
echo "$(blkid | awk '/md0/ { print $2 }') /mnt/raid0 ext3 defaults 0 0" >> /etc/fstab
echo "$(blkid | awk '/md1/ { print $2 }') /mnt/raid1 xfs defaults 0 0" >> /etc/fstab
echo "$(blkid | awk '/md5/ { print $2 }') /mnt/raid5 ext4 defaults 0 0" >> /etc/fstab
echo "$(blkid | awk '/md10/ { print $2 }') /mnt/raid10 xfs defaults 0 0" >> /etc/fstab
###
dd if=/dev/urandom of=/mnt/raid0/raid0-file bs=1M count=100
dd if=/dev/urandom of=/mnt/raid1/raid1-file bs=1M count=100
dd if=/dev/urandom of=/mnt/raid5/raid5-file bs=1M count=100
dd if=/dev/urandom of=/mnt/raid10/raid10-file bs=1M count=100