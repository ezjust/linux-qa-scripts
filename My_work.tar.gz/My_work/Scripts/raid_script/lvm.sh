#!/bin/bash
###
# Before running the script add 8 (seven) disks all with 4 GB capacity 
###
pvcreate /dev/sd[bcdefghi]
###
vgcreate vg1 /dev/sd[bc]
vgcreate vg2 /dev/sd[def]
vgcreate vg3 /dev/sd[ghi]
###
lvcreate -l 100%FREE -n linearlv vg1
lvcreate -L 3G -i 3 -n stripelv vg2
lvcreate --type mirror -L 1G -n mirrorlv -m 1 vg3 /dev/sdg /dev/sdh /dev/sdi
###
mkdir /mnt/linearlv /mnt/stripelv /mnt/mirrorlv
###
mkfs.xfs /dev/vg1/linearlv
mkfs.ext3 /dev/vg2/stripelv
mkfs.ext4 /dev/vg3/mirrorlv
###
mount /dev/vg1/linearlv /mnt/linearlv/
mount /dev/vg2/stripelv /mnt/stripelv/
mount /dev/vg3/mirrorlv /mnt/mirrorlv/
###
dd if=/dev/urandom of=/mnt/linearlv/lin-file bs=1M count=50
dd if=/dev/urandom of=/mnt/stripelv/str-file bs=1M count=50
dd if=/dev/urandom of=/mnt/mirrorlv/mir-file bs=1M count=50
###
echo "$(blkid | awk '/linear/ { print $2 }') /mnt/linearlv xfs defaults 0 0" >> /etc/fstab
echo "$(blkid | awk '/stripe/ { print $2 }') /mnt/stripelv ext3 defaults 0 0" >> /etc/fstab
echo "$(blkid | awk '/mirror/ { print $2 }') /mnt/mirrorlv ext4 defaults 0 0" >> /etc/fstab
