#!/bin/bash

_number=0
_hd=0

_root_device="none"
_boot_device="none"
_device="none"
_root_path=""
_boot_path=""

resolve_root() {
    echo "Looking for root device."
    [ ${_root_device} == "none" ] && {
    mounts=($(mount | grep "/mnt" | cut -d ' ' -f3))
    for root_mount in ${mounts[@]} ; do
        [ -e $root_mount/.blksnap/attached-devices  ] && {
            _root_device=`mount | grep $root_mount | cut -d ' ' -f1`
            _device=$_root_device
            _root_path="$root_mount"
            _boot_path="$root_path/boot"
            [ ! -f $root_path/etc/SuSE-release ] || [ "`cat $root_path/etc/SuSE-release | grep "VERSION" | cut -d '=' -f2 | grep -o '[0-9]\+'`" != "11" ] {
                echo "This script is applicable only for SLES 11"
                exit 1
            }

            echo "Found root device at $_root_device"
            [ ! -d $root_mount/boot/grub ] && {
            echo "Looking for boot device."
            for boot_mount in ${mounts[@]} ; do
                [ -d $boot_mount/grub ] && {
                echo "Found boot device at $_boot_device"
                _boot_device=`mount | grep $boot_mount | cut -d ' ' -f1`
                _device=$_boot_device
                [[ "$boot_mount" =~ "$root_mount" ]] || {
                    mount $_boot_device $root_mount/boot
                }

                return
                }
            done
            } || return
        }
    done

    echo "Root or boot device couldn't be resolved."
    exit 1
    }
}

resolve_hd() {
    signature=`echo $_root_device | sed 's|/dev/sd||g'`
    letters=($(echo $signature | grep -o "[a-zA-Z]\+" | grep -o .))
    _number=`echo $signature | grep -o "[0-9]\+"`
    i=0
    _hd=0
    for char in ${letters[@]} ; do
        id=`echo -n "$char" | od -t x1 | head -n1 | cut -d ' ' -f2`;
        let "_hd=$_hd+26**(${#letters[@]}-$i-1)*($id-60)"
        let "i=$i+1"
    done
    let "_hd=$_hd-1"
    echo "Resolved HD number and partition number to boot into hd($_hd,$_number)"
}

# $_boot_path/grub/device.map
# $_boot_path/grub2/device.map
patch_device_map() {
    echo "Patching device.map file. Backup will be saved at /boot/grub/device.map.backup"
    cp $1 "$1".backup
    sed "s|^(hd$_hd).\+||g" -i $1
    echo "(hd$_hd)   $_device" >> $1
}

# $_boot_path/grub/menu.lst
patch_menu_lst() {
    echo "Patching menu.lst file. Backup will be saved at /boot/grub/menu.lst"
    cp $1 "$1".backup
    sed "s|root (hd[0-9]\+,[0-9]\+|root (hd$_hd,$_number)|g" -i $1
    sed "s|root=[a-zA-Z0-9/]|root=$_device|g" -i $1
}

update_initrd() {
    echo "Updating initrd for all installed kernels."
    mount -t proc /proc $_root_path/proc
    mount -o bind /dev $_root_path/dev
    mount -o bind /sys $_root_path/sys

    chroot $_root_path /sbin/mkinitrd

    umount $_root_path/proc
    umount $_root_path/dev
    umount $_root_path/sys
}

resolve_root

resolve_hd

patch_device_map $_boot_path/grub/device.map

patch_menu_lst $_boot_path/grub/menu.lst

update_initrd

umount $_boot_path

exit 0
