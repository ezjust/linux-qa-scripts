#!/bin/bash
#
# Before running the script install packages
# yum install lvm2 mdadm
#
# Also add several disks to machine
#  3 x 4G - LVM
#  6 x 2G - RAID  
#  2 x 10G - unalign partitions and diff block size
#  1 x 5G - without partition table
#
# Script should be performed with root privileges
#
####################################################################################################
#
#
# Creating partiton table and partitions for LVM volumes
parted -s /dev/sdb mklabel gpt mkpart p1 2048s 100% set 1 lvm on
parted -s /dev/sdc mklabel gpt mkpart p1 2048s 100% set 1 lvm on
parted -s /dev/sdd mklabel gpt mkpart p1 2048s 100% set 1 lvm on
# Creating physical volumes on partitions sdb1, sdc1, sdd1
pvcreate /dev/sd[bcd]1
# Creating volume group (named lvm)
vgcreate lvm /dev/sd[bcd]1
# Creating first logical volume (named lvmext4)
lvcreate --name lvmext4 --size 5.9G lvm
# Create second logical volume (named lvmext3)
lvcreate --name lvmext3 --size 5.9G lvm
# Making ext4 fs on lvm volume /dev/lvm/lvmext4
mkfs.ext4 /dev/lvm/lvmext4
# Making ext3 fs on lvm volume /dev/lvm/lvmext3
mkfs.ext3 /dev/lvm/lvmext3
# Creating directories to mount lvm volumes
mkdir /mnt/lvmext4
mkdir /mnt/lvmext3
# Mounting lvm volumes to mount points
mount /dev/lvm/lvmext4 /mnt/lvmext4
mount /dev/lvm/lvmext3 /mnt/lvmext3
# Modifying /etc/fstab to mount lvm volumes automatically
echo '###' >> /etc/fstab
echo "$(blkid | awk '/lvmext4/ { print $2 }') /mnt/lvmext4 ext4 defaults 0 0" >> /etc/fstab
echo "$(blkid | awk '/lvmext3/ { print $2 }') /mnt/lvmext3 ext3 defaults 0 0" >> /etc/fstab
echo '###' >> /etc/fstab
# Generating data in LVM
dd if=/dev/urandom of=/mnt/lvmext4/100Mfile bs=1M count=100

mkdir -p /mnt/lvmext4/indir1/indir2
i=1
while [ $i -lt 101 ]
	do
		dd if=/dev/urandom of=/mnt/lvmext4/indir1/indir2/$i-10Kfile bs=10K count=1
		i=$[$i+1]
	done

dd if=/dev/urandom of=/mnt/lvmext3/100Mfile bs=1M count=100

mkdir -p /mnt/lvmext3/indir1/indir2
i=1
while [ $i -lt 101 ]
        do
                dd if=/dev/urandom of=/mnt/lvmext3/indir1/indir2/$i-10Kfile bs=10K count=1
                i=$[$i+1]
        done
####################################################################################################
#
#
# Creating partiton table and partitions for RAID
parted -s /dev/sde mklabel gpt mkpart p1 2048s 100% set 1 raid on
parted -s /dev/sdf mklabel gpt mkpart p1 2048s 100% set 1 raid on
parted -s /dev/sdg mklabel gpt mkpart p1 2048s 100% set 1 raid on
parted -s /dev/sdh mklabel gpt mkpart p1 2048s 100% set 1 raid on
parted -s /dev/sdi mklabel gpt mkpart p1 2048s 100% set 1 raid on
parted -s /dev/sdj mklabel gpt mkpart p1 2048s 100% set 1 raid on
# Creating first RAID5 /dev/md127
mdadm --create /dev/md127 --verbose --level=raid5 --raid-devices=3 /dev/sde1 /dev/sdf1 /dev/sdg1
# Creating second RAID5 /dev/md128
mdadm --create /dev/md128 --verbose --level=raid5 --raid-devices=3 /dev/sdh1 /dev/sdi1 /dev/sdj1
# Making ext3 and ext4 fs on both RAID5
mkfs.ext3 /dev/md127
mkfs.ext4 /dev/md128
# Creating directories to mount RAID5
mkdir /mnt/raidext3
mkdir /mnt/raidext4
# Mounting RAID5 to mount points
mount /dev/md127 /mnt/raidext3
mount /dev/md128 /mnt/raidext4
# Modifying /etc/fstab to mount RAID volumes automatically
echo '###' >> /etc/fstab
echo "$(blkid | awk '/md127/ { print $2 }') /mnt/raidext3 ext3 defaults 0 0" >> /etc/fstab
echo "$(blkid | awk '/md128/ { print $2 }') /mnt/raidext4 ext4 defaults 0 0" >> /etc/fstab
echo '###' >> /etc/fstab
# Generating data in RAID
dd if=/dev/urandom of=/mnt/raidext3/100Mfile bs=1M count=100

mkdir -p /mnt/raidext3/indir1/indir2
i=1
while [ $i -lt 101 ]
        do
                dd if=/dev/urandom of=/mnt/raidext3/indir1/indir2/$i-10Kfile bs=10K count=1
                i=$[$i+1]
        done

dd if=/dev/urandom of=/mnt/raidext4/100Mfile bs=1M count=100

mkdir -p /mnt/raidext4/indir1/indir2
i=1
while [ $i -lt 101 ]
        do
                dd if=/dev/urandom of=/mnt/raidext4/indir1/indir2/$i-10Kfile bs=10K count=1
                i=$[$i+1]
        done
####################################################################################################
#
#
# Creating unalign partitions
parted -s /dev/sdk mklabel gpt mkpart p1 ext2 3072s 11000000s mkpart p2 ext2 11000001s 100%
parted -s /dev/sdl mklabel gpt mkpart p1 ext2 3072s 11000000s mkpart p2 ext2 11000001s 100%
# Making fs for unalign partitions
mkfs.ext3 -b 2560 /dev/sdk1
mkfs.ext4 -b 2560 /dev/sdk2
mkfs.ext4 -b 2560 /dev/sdl1
mkfs.ext3 -b 2560 /dev/sdl2
# Creating directories to mount unalign volumes
mkdir /mnt/unext3-1
mkdir /mnt/unext4-1
mkdir /mnt/unext4-2
mkdir /mnt/unext3-2
# Mounting unalign volumes to mount points
mount /dev/sdk1 /mnt/unext3-1
mount /dev/sdk2 /mnt/unext4-1
mount /dev/sdl1 /mnt/unext4-2
mount /dev/sdl2 /mnt/unext3-2
# Modifying /etc/fstab to mount volumes automatically
echo '###' >> /etc/fstab
echo "$(blkid | awk '/sdk1/ { print $2 }') /mnt/unext3-1 ext3 defaults 0 0" >> /etc/fstab
echo "$(blkid | awk '/sdk2/ { print $2 }') /mnt/unext4-1 ext4 defaults 0 0" >> /etc/fstab
echo "$(blkid | awk '/sdl1/ { print $2 }') /mnt/unext4-2 ext4 defaults 0 0" >> /etc/fstab
echo "$(blkid | awk '/sdl2/ { print $2 }') /mnt/unext3-2 ext3 defaults 0 0" >> /etc/fstab
echo '###' >> /etc/fstab
# Generating data in unalign partitions
dd if=/dev/urandom of=/mnt/unext3-1/100Mfile bs=1M count=100

mkdir -p /mnt/unext3-1/indir1/indir2
i=1
while [ $i -lt 101 ]
        do
                dd if=/dev/urandom of=/mnt/unext3-1/indir1/indir2/$i-10Kfile bs=10K count=1
                i=$[$i+1]
        done

dd if=/dev/urandom of=/mnt/unext4-1/100Mfile bs=1M count=100

mkdir -p /mnt/unext4-1/indir1/indir2
i=1
while [ $i -lt 101 ]
        do
                dd if=/dev/urandom of=/mnt/unext4-1/indir1/indir2/$i-10Kfile bs=10K count=1
                i=$[$i+1]
        done

dd if=/dev/urandom of=/mnt/unext4-2/100Mfile bs=1M count=100

mkdir -p /mnt/unext4-2/indir1/indir2
i=1
while [ $i -lt 101 ]
        do
                dd if=/dev/urandom of=/mnt/unext4-2/indir1/indir2/$i-10Kfile bs=10K count=1
                i=$[$i+1]
        done

dd if=/dev/urandom of=/mnt/unext3-2/100Mfile bs=1M count=100

mkdir -p /mnt/unext3-2/indir1/indir2
i=1
while [ $i -lt 101 ]
        do
                dd if=/dev/urandom of=/mnt/unext3-2/indir1/indir2/$i-10Kfile bs=10K count=1
                i=$[$i+1]
        done
####################################################################################################
#
#
# Making fs on disk without partition table
mkfs.ext4 -F /dev/sdm
# Creating directory to mount volume
mkdir /mnt/noptext4
# Mounting volume
mount /dev/sdm /mnt/noptext4
echo '###' >> /etc/fstab
echo "$(blkid | awk '/sdm/ { print $2 }') /mnt/noptext4 ext4 defaults 0 0" >> /etc/fstab
echo '###' >> /etc/fstab
# Generating data on volume
dd if=/dev/urandom of=/mnt/noptext4/100Mfile bs=1M count=100

mkdir -p /mnt/noptext4/indir1/indir2
i=1
while [ $i -lt 101 ]
        do
                dd if=/dev/urandom of=/mnt/noptext4/indir1/indir2/$i-10Kfile bs=10K count=1
                i=$[$i+1]
        done
exit

