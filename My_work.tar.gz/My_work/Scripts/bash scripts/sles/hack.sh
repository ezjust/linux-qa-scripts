###

vgchange -ay
mount /dev/lvm/lvmext3 /mnt/lvmext3
mount /dev/lvm/lvmxfs /mnt/lvmxfs
mdadm -A -s
mount /dev/md127 /mnt/raidext3
mount /dev/md128 /mnt/raidxfs
mount /dev/sdk1 /mnt/5ext3
mount /dev/sdk2 /mnt/5ext3-2
mount /dev/sdl1 /mnt/5ext3-3
mount /dev/sdl2 /mnt/5xfs
mount /dev/sdm /mnt/sdmext3



















