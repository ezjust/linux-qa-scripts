#!/bin/bash

###Create physical volumes on partitions sdb1, sdc1, sdd1
pvcreate /dev/sd[bcd]1

###Create volume group (named lvm) with disks
vgcreate lvm /dev/sd[bcd]1

###Create first logic volume (named lvmext4)
lvcreate --name lvmext3 --size 5.9G lvm

###Create second logic volume (named lvmxfs)
lvcreate --name lvmxfs --size 5.9G lvm

###Make ext4 fs on lvm volume /dev/lvm/lvmext4
mkfs.ext3 /dev/lvm/lvmext3

###Make xfs fs on lvm volume /dev/lvm/lvmxfs
mkfs.xfs /dev/lvm/lvmxfs

###Create directories to mount lvm volumes
mkdir /mnt/lvmext3
mkdir /mnt/lvmxfs

###Mount lvm volumes to mount points
mount /dev/lvm/lvmext3 /mnt/lvmext3
mount /dev/lvm/lvmxfs /mnt/lvmxfs

###Modify /etc/fstab to mount lvm volumes automatically
echo '###' >> /etc/fstab
echo '/dev/mapper/lvm-lvmext3	/mnt/lvmext3	ext3	defaults	1	1' >> /etc/fstab
echo '/dev/mapper/lvm-lvmxfs	/mnt/lvmxfs		xfs		defaults	1	1' >> /etc/fstab
echo '###' >> /etc/fstab