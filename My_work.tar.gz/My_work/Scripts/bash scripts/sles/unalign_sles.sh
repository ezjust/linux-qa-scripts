#/bin/bash

###Make fs
mkfs.ext3 -b 2560 /dev/sdk1
mkfs.ext3 -b 2560 /dev/sdk2
mkfs.ext3 -b 2560 /dev/sdl1
mkfs.xfs -fb size=1024 /dev/sdl2

###Create directories to mount volumes
mkdir /mnt/5ext3
mkdir /mnt/5ext3-2
mkdir /mnt/5ext3-3
mkdir /mnt/5xfs

###Mount volumes to your mount points
mount /dev/sdk1 /mnt/5ext3
mount /dev/sdk2 /mnt/5ext3-2
mount /dev/sdl1 /mnt/5ext3-3
mount /dev/sdl2 /mnt/5xfs

###Modify /etc/fstab to mount volumes automatically
echo '###' >> /etc/fstab
echo '/dev/sdk1		/mnt/5ext3		ext3	defaults	1	1' >> /etc/fstab
echo '/dev/sdk2		/mnt/5ext3-2	ext3	defaults	1	1' >> /etc/fstab
echo '/dev/sdl1		/mnt/5ext3-3	ext3	defaults	1	1' >> /etc/fstab
echo '/dev/sdl2		/mnt/5xfs		xfs		defaults	1	1' >> /etc/fstab
echo '###' >> /etc/fstab