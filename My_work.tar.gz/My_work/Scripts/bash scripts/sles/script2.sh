#!/bin/bash

###Generating data for LVM

dd if=/dev/urandom of=/mnt/lvmext4/10M bs=1M count=10



dd if=/dev/urandom of=/mnt/lvmxfs/10M bs=1M count=10



###Generating data for RAID

dd if=/dev/urandom of=/mnt/raidext3/10M bs=1M count=10



dd if=/dev/urandom of=/mnt/raidxfs/10M bs=1M count=10



###Generating data for others

dd if=/dev/urandom of=/mnt/5ext3/10M bs=1M count=10



dd if=/dev/urandom of=/mnt/5ext4/10M bs=1M count=10



dd if=/dev/urandom of=/mnt/5ext4-2/10M bs=1M count=10



dd if=/dev/urandom of=/mnt/5xfs/10M bs=1M count=10



###Generating data for disk without partition table

dd if=/dev/urandom of=/mnt/sdmext4/10M bs=1M count=10



