#!/bin/bash

###Create first RAID5 /dev/md127
mdadm --create /dev/md127 --verbose --level=raid5 --raid-devices=3 /dev/sde1 /dev/sdf1 /dev/sdg1

###Create second RAID5 /dev/md128
mdadm --create /dev/md128 --verbose --level=raid5 --raid-devices=3 /dev/sdh1 /dev/sdi1 /dev/sdj1

###Make ext3 and xfs fs on both RAID5
mkfs.ext3 /dev/md127
mkfs.xfs /dev/md128

###Create directories to mount RAID5
mkdir /mnt/raidext3
mkdir /mnt/raidxfs

###Mount RAID5 to your mount points
mount /dev/md127 /mnt/raidext3
mount /dev/md128 /mnt/raidxfs

###Modify /etc/fstab to mount RAID volumes automatically
echo '###' >> /etc/fstab
echo '/dev/md127	/mnt/raidext3	ext3	defaults	1	1' >> /etc/fstab
echo '/dev/md128	/mnt/raidxfs	xfs		defaults	1	1' >> /etc/fstab
echo '###' >> /etc/fstab

###
cat /proc/mdstat