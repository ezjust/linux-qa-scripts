#/bin/bash

###Create directory to mount volume
mkdir /mnt/sdmext3

###Mount volume
mount /dev/sdm /mnt/sdmext3

###Modify /etc/fstab to mount volume automatically
echo '###' >> /etc/fstab
echo '/dev/sdm		/mnt/sdmext3	ext3	defaults	1	1' >> /etc/fstab
echo '###' >> /etc/fstab