#!/bin/bash
#
###Create physical volumes on partitions sdb1, sdc1, sdd1
pvcreate /dev/sd[bcd]1

###Create volume group (named lvm) with disks
vgcreate lvm /dev/sd[bcd]1

###Create first logic volume (named lvmext4)
lvcreate --name lvmext4 --size 5.9G lvm

###Create second logic volume (named lvmxfs)
lvcreate --name lvmxfs --size 5.9G lvm

###Make ext4 fs on lvm volume /dev/lvm/lvmext4
mkfs.ext4 /dev/lvm/lvmext4

###Make xfs fs on lvm volume /dev/lvm/lvmxfs
mkfs.xfs /dev/lvm/lvmxfs

###Create directories to mount lvm volumes
mkdir /mnt/lvmext4
mkdir /mnt/lvmxfs

###Mount lvm volumes to mount points
mount /dev/lvm/lvmext4 /mnt/lvmext4
mount /dev/lvm/lvmxfs /mnt/lvmxfs

###Modify /etc/fstab to mount lvm volumes automatically
echo '###' >> /etc/fstab
echo '/dev/mapper/lvm-lvmext4	/mnt/lvmext4	ext4	defaults	0	1' >> /etc/fstab
echo '/dev/mapper/lvm-lvmxfs	/mnt/lvmxfs		xfs		defaults	0	1' >> /etc/fstab
echo '###' >> /etc/fstab
#
#########################################################################################
#
###Create first RAID5 /dev/md127
mdadm --create /dev/md127 --verbose --level=raid5 --raid-devices=3 /dev/sde1 /dev/sdf1 /dev/sdg1

###Create second RAID5 /dev/md128
mdadm --create /dev/md128 --verbose --level=raid5 --raid-devices=3 /dev/sdh1 /dev/sdi1 /dev/sdj1

###Make ext3 and xfs fs on both RAID5
mkfs.ext3 /dev/md127
mkfs.xfs /dev/md128

###Create directories to mount RAID5
mkdir /mnt/raidext3
mkdir /mnt/raidxfs

###Mount RAID5 to your mount points
mount /dev/md127 /mnt/raidext3
mount /dev/md128 /mnt/raidxfs

###Modify /etc/fstab to mount RAID volumes automatically
echo '###' >> /etc/fstab
echo '/dev/md127	/mnt/raidext3	ext3	defaults	0	1' >> /etc/fstab
echo '/dev/md128	/mnt/raidxfs	xfs		defaults	0	1' >> /etc/fstab
echo '###' >> /etc/fstab
#
#########################################################################################
#
###Make fs
mkfs.ext3 -b 2560 /dev/sdk1
mkfs.ext4 -b 2560 /dev/sdk2
mkfs.ext4 -b 2560 /dev/sdl1
mkfs.xfs -fb size=1024 /dev/sdl2

###Create directories to mount volumes
mkdir /mnt/5ext3
mkdir /mnt/5ext4
mkdir /mnt/5ext4-2
mkdir /mnt/5xfs

###Mount volumes to your mount points
mount /dev/sdk1 /mnt/5ext3
mount /dev/sdk2 /mnt/5ext4
mount /dev/sdl1 /mnt/5ext4-2
mount /dev/sdl2 /mnt/5xfs

###Modify /etc/fstab to mount volumes automatically
echo '###' >> /etc/fstab
echo '/dev/sdk1		/mnt/5ext3		ext3	defaults	0	1' >> /etc/fstab
echo '/dev/sdk2		/mnt/5ext4		ext4	defaults	0	1' >> /etc/fstab
echo '/dev/sdl1		/mnt/5ext4-2	ext4	defaults	0	1' >> /etc/fstab
echo '/dev/sdl2		/mnt/5xfs		xfs		defaults	0	1' >> /etc/fstab
echo '###' >> /etc/fstab
#
#########################################################################################
#
###Make fs
mkfs.ext4 -F /dev/sdm
###Create directory to mount volume
mkdir /mnt/sdmext4

###Mount volume
mount /dev/sdm /mnt/sdmext4

###Modify /etc/fstab to mount volume automatically
echo '###' >> /etc/fstab
echo '/dev/sdm		/mnt/sdmext4	ext4	defaults	0	1' >> /etc/fstab
echo '###' >> /etc/fstab
#
#########################################################################################
#
cat /proc/mdstat

