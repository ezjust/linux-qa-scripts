#!/bin/bash

###Create physical volumes on partitions sdb1, sdc1, sdd1
pvcreate /dev/sd[bcd]1

###Create volume group (named lvm) with disks
vgcreate lvm /dev/sd[bcd]1

###Create first logic volume (named lvmext4)
lvcreate --name lvmext4 --size 5.9G lvm

###Create second logic volume (named lvmxfs)
lvcreate --name lvmxfs --size 5.9G lvm

###Make ext4 fs on lvm volume /dev/lvm/lvmext4
mkfs.ext4 /dev/lvm/lvmext4

###Make xfs fs on lvm volume /dev/lvm/lvmxfs
mkfs.xfs /dev/lvm/lvmxfs

###Create directories to mount lvm volumes
mkdir /mnt/lvmext4
mkdir /mnt/lvmxfs

###Mount lvm volumes to mount points
mount /dev/lvm/lvmext4 /mnt/lvmext4
mount /dev/lvm/lvmxfs /mnt/lvmxfs

###Modify /etc/fstab to mount lvm volumes automatically
echo '###' >> /etc/fstab
echo '/dev/mapper/lvm-lvmext4	/mnt/lvmext4	ext4	defaults	0	1' >> /etc/fstab
echo '/dev/mapper/lvm-lvmxfs	/mnt/lvmxfs		xfs		defaults	0	1' >> /etc/fstab
echo '###' >> /etc/fstab