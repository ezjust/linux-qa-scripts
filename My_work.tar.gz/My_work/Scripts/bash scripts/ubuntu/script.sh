#!/bin/bash

###Generating data for LVM

dd if=/dev/urandom of=/mnt/lvmext4/100Mfile bs=1M count=100

mkdir -p /mnt/lvmext4/indir1/indir2
i=1
while [ $i -lt 101 ]
	do
		dd if=/dev/urandom of=/mnt/lvmext4/indir1/indir2/$i-10Kfile bs=10K count=1
		i=$[$i+1]
	done

dd if=/dev/urandom of=/mnt/lvmxfs/100Mfile bs=1M count=100

mkdir -p /mnt/lvmxfs/indir1/indir2
i=1
while [ $i -lt 101 ]
        do
                dd if=/dev/urandom of=/mnt/lvmxfs/indir1/indir2/$i-10Kfile bs=10K count=1
                i=$[$i+1]
        done

###Generating data for RAID

dd if=/dev/urandom of=/mnt/raidext3/100Mfile bs=1M count=100

mkdir -p /mnt/raidext3/indir1/indir2
i=1
while [ $i -lt 101 ]
        do
                dd if=/dev/urandom of=/mnt/raidext3/indir1/indir2/$i-10Kfile bs=10K count=1
                i=$[$i+1]
        done

dd if=/dev/urandom of=/mnt/raidxfs/100Mfile bs=1M count=100

mkdir -p /mnt/raidxfs/indir1/indir2
i=1
while [ $i -lt 101 ]
        do
                dd if=/dev/urandom of=/mnt/raidxfs/indir1/indir2/$i-10Kfile bs=10K count=1
                i=$[$i+1]
        done

###Generating data for others

dd if=/dev/urandom of=/mnt/5ext3/100Mfile bs=1M count=100

mkdir -p /mnt/5ext3/indir1/indir2
i=1
while [ $i -lt 101 ]
        do
                dd if=/dev/urandom of=/mnt/5ext3/indir1/indir2/$i-10Kfile bs=10K count=1
                i=$[$i+1]
        done

dd if=/dev/urandom of=/mnt/5ext4/100Mfile bs=1M count=100

mkdir -p /mnt/5ext4/indir1/indir2
i=1
while [ $i -lt 101 ]
        do
                dd if=/dev/urandom of=/mnt/5ext4/indir1/indir2/$i-10Kfile bs=10K count=1
                i=$[$i+1]
        done

dd if=/dev/urandom of=/mnt/5ext4-2/100Mfile bs=1M count=100

mkdir -p /mnt/5ext4-2/indir1/indir2
i=1
while [ $i -lt 101 ]
        do
                dd if=/dev/urandom of=/mnt/5ext4-2/indir1/indir2/$i-10Kfile bs=10K count=1
                i=$[$i+1]
        done

dd if=/dev/urandom of=/mnt/5xfs/100Mfile bs=1M count=100

mkdir -p /mnt/5xfs/indir1/indir2
i=1
while [ $i -lt 101 ]
        do
                dd if=/dev/urandom of=/mnt/5xfs/indir1/indir2/$i-10Kfile bs=10K count=1
                i=$[$i+1]
        done

###Generating data for disk without partition table

dd if=/dev/urandom of=/mnt/sdmext4/100Mfile bs=1M count=100

mkdir -p /mnt/sdmext4/indir1/indir2
i=1
while [ $i -lt 101 ]
        do
                dd if=/dev/urandom of=/mnt/sdmext4/indir1/indir2/$i-10Kfile bs=10K count=1
                i=$[$i+1]
        done

