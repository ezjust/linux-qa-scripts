#!/bin/bash

branch="release-6.0.2"
download_link_base="http://s3.amazonaws.com/repolinux/release-6.0.2"
packages=()

print_query() {
    echo "Downloaded packages will be put in folder ~/rapidrecovery.packages/"
    echo "Please select you distribution and architecture:"
    echo "0 - SLES 11 x64"
    echo "1 - SLES 11 x86"
    echo "2 - SLES 12 x64"
    echo "3 - RHEL 7 x64"
    echo "4 - RHEL 6 x64"
    echo "5 - RHEL 6 x86"
    echo "6 - Ubuntu x64"
    echo "7 - Ubuntu x86"
    echo "8 - Debian 7 x64"
    echo "9 - Debian 7 x86"
    echo "10 - Debian 8 x64"
    echo "11 - Debian 8 x86"
}

read_answer() {
    if [ -z "$1" ] ; then
        read line || break
    else
        line=$1
    fi

    packages=()
    download_link=""
    case $line in
        0) download_link=$download_link_base/repo/SLES/11/x86_64
           packages+=("rapidrecovery-agent-$version-sles11-x86_64.rpm")
           packages+=("rapidrecovery-mono-$version-sles11-x86_64.rpm")
           packages+=("dkms-$dkms_version-sysv.noarch.rpm")
           distrib="SLES 11 x64"
           return 0;;
        1) download_link=$download_link_base/repo/SLES/11/i386
           packages+=("rapidrecovery-agent-$version-sles11-x86_32.rpm")
           packages+=("rapidrecovery-mono-$version-sles11-x86_32.rpm")
           packages+=("dkms-$dkms_version-sysv.noarch.rpm")
           distrib="SLES 11 x86"
           return 0;;
        2) download_link=$download_link_base/repo/SLES/12/x86_64
           packages+=("rapidrecovery-agent-$version-sles12-x86_64.rpm")
           packages+=("rapidrecovery-mono-$version-sles12-x86_64.rpm")
           packages+=("dkms-$dkms_version-sysv.noarch.rpm")
           distrib="SLES 12 x64"
           return 0;;
        3) download_link=$download_link_base/repo/RHEL/7/x86_64
           packages+=("rapidrecovery-agent-$version-rhel7-x86_64.rpm")
           packages+=("rapidrecovery-mono-$version-rhel7-x86_64.rpm")
           packages+=("dkms-$dkms_version-systemd.noarch.rpm")
           packages+=("nbd-$version-rhel7-x86_64.rpm")
           distrib="RHEL 7 x64"
           return 0;;
        4) download_link=$download_link_base/repo/RHEL/6/x86_64
           packages+=("rapidrecovery-agent-$version-rhel6-x86_64.rpm")
           packages+=("rapidrecovery-mono-$version-rhel6-x86_64.rpm")
           packages+=("dkms-$dkms_version-sysv.noarch.rpm")
           packages+=("nbd-$version-rhel6-x86_64.rpm")
           distrib="RHEL 6 x64"
           return 0;;
        5) download_link=$download_link_base/repo/RHEL/6/i386
           packages+=("rapidrecovery-agent-$version-rhel6-x86_32.rpm")
           packages+=("rapidrecovery-mono-$version-rhel6-x86_32.rpm")
           packages+=("dkms-$dkms_version-sysv.noarch.rpm")
           packages+=("nbd-$version-rhel6-x86_32.rpm")
           distrib="RHEL 6 x86"
           return 0;;
        6) download_link=$download_link_base/repo/ubuntu
           packages+=("rapidrecovery-agent-$version-ubuntu-x86_64.deb")
           packages+=("rapidrecovery-mono-$version-ubuntu-x86_64.deb")
           packages+=("dkms-$dkms_version-sysv.noarch.deb")
           distrib="Ubuntu x64"
           return 0;;
        7) download_link=$download_link_base/repo/ubuntu
           packages+=("rapidrecovery-agent-$version-ubuntu-x86_32.deb")
           packages+=("rapidrecovery-mono-$version-ubuntu-x86_32.deb")
           packages+=("dkms-$dkms_version-sysv.noarch.deb")
           distrib="Ubuntu x86"
           return 0;;
        8) download_link=$download_link_base/repo/debian7
           packages+=("rapidrecovery-agent-$version-debian7-x86_64.deb")
           packages+=("rapidrecovery-mono-$version-debian7-x86_64.deb")
           packages+=("dkms-$dkms_version-sysv.noarch.deb")
           distrib="Debian 7 x86"
           return 0;;
        9) download_link=$download_link_base/repo/debian7
           packages+=("rapidrecovery-agent-$version-debian7-x86_32.deb")
           packages+=("rapidrecovery-mono-$version-debian7-x86_32.deb")
           packages+=("dkms-$dkms_version-sysv.noarch.deb")
           distrib="Debian 7 x86"
           return 0;;
        10) download_link=$download_link_base/repo/debian8
            packages+=("rapidrecovery-agent-$version-debian8-x86_64.deb")
            packages+=("rapidrecovery-mono-$version-debian8-x86_64.deb")
            packages+=("dkms-$dkms_version-systemd.noarch.deb")
            distrib="Debian 8 x86"
            return 0;;
        11) download_link=$download_link_base/repo/debian8
            packages+=("rapidrecovery-agent-$version-debian8-x86_32.deb")
            packages+=("rapidrecovery-mono-$version-debian7-x86_32.deb")
            packages+=("dkms-$dkms_version-systemd.noarch.deb")
            distrib="Debian 8 x86"
            return 0;;
        *) echo "Incorrect input: '$line'. Please try again."
           return 1;;
    esac
}

if [ ! -z "$1" ] ; then
    if [ "$1" == "print" ] ; then
        for i in $(seq 0 7) ; do
            read_answer $i
            echo "Packages for $distrib can be found at:"
            for package in ${packages[@]} ; do
                echo "$download_link/$package"
            done
        done

        exit 0
    else
        if [ "$1" == "repo" ] ; then
            _uname_arch="`uname -m`"
            case "$_uname_arch" in
                i*86)          _arch='x86_32' ;;
                amd64|x86_64)  _arch='x86_64' ;;
                *)      die "Unknown architecture: $_uname_arch" ;;
            esac

            if [ -f /etc/debian_version ] ; then
                _distro_name='debian'
                if `cat /etc/os-release | grep 'NAME="Ubuntu"' 1>/dev/null 2>&1` ; then
                    _distro_ver=`cat /etc/os-release | grep "VERSION_ID" | cut -d '=' -f2 | sed 's|"||g' | cut -d '.' -f1`
                    # Ubuntu starts using systemd from version 15
                    if [ $_distro_ver -gt 14 ] ; then
                        _distro_ver=8
                    else
                        _distro_ver=7
                    fi
                else
                    _distro_ver=`cat /etc/os-release | grep "VERSION_ID" | cut -d '=' -f2 | sed 's|"||g'`
                    # Why? Because it will run on customer envs. And it may want to install our agent on debian 6, or 9
                    if [ $_distro_ver -gt 7 ] ; then
                        _distro_ver=8
                    else
                        _distro_ver=7
                    fi
                fi

                _package_manager='deb'
            elif [ -f /etc/SuSE-release ] ; then
                _distro_name='sles'
                _distro_ver=`lsb_release -r | cut -d ':' -f2 | sed 's|\s*||g'`
                _package_manager='rpm'
            elif [ -f /etc/redhat-release ] ; then
                _distro_name='rhel'
                _package_manager='rpm'
                case "`sed 's/^.*release //' </etc/redhat-release`" in
                    7*) _distro_ver=7 ;;
                    6*) _distro_ver=6 ;;
                    5*) _distro_ver=5 ;;
                esac
            else
                die "Unknown Linux distribution"
            fi

            wget http://s3.amazonaws.com/appassure5linux/$2/repo-packages/rapidrecovery-repo-$_distro_name$_distro_ver-$_arch.$_package_manager -O /tmp/repo-installer.$_package_manager
            exit $?
        fi

        echo "Incorrect command line parameter '$1'. Allowed option is 'print'."
        exit 1
    fi
fi

wget $download_link_base/version
version=`cat version`
rm version

wget $download_link_base/dkms_version
dkms_version=`cat dkms_version`
rm dkms_version

print_query

while ! read_answer ; do
    print_query
done

mkdir -p ~/rapidrecovery.packages/
for package in ${packages[@]} ; do
    wget $download_link/$package -O ~/rapidrecovery.packages/$package
done
