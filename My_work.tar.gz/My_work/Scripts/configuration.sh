#!/bin/bash

#tty -s $$ export TTY=true

do_print_hello() {
#test "$TTY" || return
cat <<EOF
		==================		
		disk configuration
		==================
EOF
}

do_print_menu() {
echo -e "
[1] LVM					- Configure LVM disks
[2] RAID				- Configure RAID disks
[3] Un. Partitions			- Configure disks with unaligned partitions
[4] Without partitions			- Configure disks without partitions
[0] Quit				- Quit"
}

subconfiguration() {
	echo "Enter how much partitions do you want(maximum four partitions): "
	read line1
	line=$line1
	case "$line1[0]" in
		1|2|3|4)	lvm_configuration "$@" ;;
	esac
}

lvm_configuration() {
	local _arg1="$1"
	local _arg2="$2"
	#subconfiguration
		
		#Creating partition table and partitions for LVM volumes
		for i in $(eval echo {$_arg1..$_arg2}); do
			echo "parted -s /dev/sd$i mklabel gpt mkpart p1 4096s 100% set 1 lvm on"
		done
		#Creating physical volumes on partitions
		for i in $(eval echo {$_arg1..$_arg2}); do
			echo "pvcreate /dev/sd${i}1"
		done
		#Creating volume group (named lvm)
		for i in $(eval echo {$_arg1..$_arg2}); do
			echo "vgcreate lvm /dev/sd${i}1"
		done
		#Creating first logical volume (named lvmext4)
		echo "lvcreate --name lvmext4 --size 33% lvm"
		#Creating second logical volume (named lvmxfs)
		echo "lvcreate --name lvmxfs --size 33% lvm"
		#Creating third logical volume (named lvmext3)
		echo "lvcreate --name lvmext3 --size 33% lvm"
		#Making ext4 fs on lvm volume /dev/lvm/lvmext4
		echo "mkfs.ext4 /dev/lvm/lvmext4"
		#Making xfs fs on lvm volume /dev/lvm/lvmxfs
		echo "mkfs.xfs /dev/lvm/lvmxfs"
		#Making ext3 fs on lvm volume /dev/lvm/lvmet3
		echo "mkfs.ext3 /dev/lvm/lmvext3"
		#Creating directories to mount lvm volumes
		echo "mkdir /mnt/lvmext4"
		echo "mkdir /mnt/lvmxfs"
		echo "mkdir /mnt/lvmext3"
		#Mounting /etc/fstab to mount lvm volumes automatically
		#echo '###' >> /etc/fstab
		#echo "$(blkid | awk '/lvmext4/ { print $2 }') /mnt/lvmext4 ext4 defaults 0 0" >> /etc/fstab 
		#echo "$(blkid | awk '/lvmxfs/ { print $2 }') /mnt/lvmxfs xfs defaults 0 0" >> /etc/fstab
		#echo "$(blkid | awk '/lvmext3/ { print $2 }') /mnt/lvmext3 ext3 defaults 0 0" >> /etc/fstab
		#echo '###' >> /etc/fstab
}

raid_configuration() {
	echo "Here will be raid configuration"
}

unpar_configuration() {
	echo "Here will be unpar configuration"
}

wpar_configuration() {
	echo "Here will be wpar configuration"
}

do_action_from_print_menu() {
	local _action="$1"
	shift

	case "$_action" in
		LVM)		lvm_configuration "$@" ;;
		RAID)		raid_configuration "$@" ;;
		Un_par)		unpar_configuration "$@" ;;
		W_par)		wpar_configuration "$@" ;;
	esac
}

do_config_shell() {
	do_print_hello

	while true; do
		do_print_menu
		#test "$TTY" && echo -n '?> '

		read line || break
		echo "User input: $line $1 $2"
		cmdline=( $line )
		case "${cmdline[0]}" in
			1|LVM|lvm)	do_action_from_print_menu 'LVM' ${cmdline[1]} ${cmdline[2]} ;;
			2|RAID|raid)	do_action_from_print_menu 'RAID' ${cmdline[1]} ${cmdline[2]} ;;
			3|unpar|up)	do_action_from_print_menu 'Un_par' ${cmdline[1]} ${cmdline[2]} ;;
			4|wpar|wp)	do_action_from_print_menu 'W_par' ${cmdline[1]} ${cmdline[2]};;
			0|q|quit)	break ;;
		esac
	done

	echo
}


do_config_shell		
