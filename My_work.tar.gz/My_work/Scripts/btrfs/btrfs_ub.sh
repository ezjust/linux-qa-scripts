#!/bin/bash

# Before running the script install btrfs-progs package
# yum install btrfs-progs -y
apt-get update && apt-get install btrfs-tools mdadm lvm2 --yes
# Also add 9 x 2Gb disks to machine

#########################################################

	parted -s /dev/sdb mklabel msdos mkpart primary 3072s 100%

	mkfs.btrfs /dev/sdb1

	mkdir /mnt/unbtrfs

	echo "$(blkid | awk '/sdb1/ { print $2 }') /mnt/unbtrfs btrfs defaults,nodatasum,device=/dev/sdb1 0 2" >> /etc/fstab

	mount -o nodatasum,device=/dev/sdb1 /dev/sdb1 /mnt/unbtrfs

	dd if=/dev/urandom of=/mnt/unbtrfs/100Mfile bs=1M count=100

	mkdir -p /mnt/unbtrfs/indir1/indir2
	i=1
	while [ $i -lt 101 ]
			do
					dd if=/dev/urandom of=/mnt/unbtrfs/indir1/indir2/$i-10Kfile bs=10K count=1
					i=$[$i+1]
			done

#########################################################

	mkfs.btrfs /dev/sdc

	mkdir /mnt/noptbtrfs

	echo "$(blkid | awk '/sdc/ { print $2 }') /mnt/noptbtrfs btrfs defaults,nodatasum,device=/dev/sdc 0 2" >> /etc/fstab

	mount -o nodatasum,device=/dev/sdc /dev/sdc /mnt/noptbtrfs

	dd if=/dev/urandom of=/mnt/noptbtrfs/100Mfile bs=1M count=100

	mkdir -p /mnt/noptbtrfs/indir1/indir2
	i=1
	while [ $i -lt 101 ]
			do
					dd if=/dev/urandom of=/mnt/noptbtrfs/indir1/indir2/$i-10Kfile bs=10K count=1
					i=$[$i+1]
			done

#########################################################

	parted -s /dev/sdd mklabel msdos mkpart primary 2048s 100%
	parted -s /dev/sde mklabel msdos mkpart primary 2048s 100%

	mkfs.btrfs -d raid0 -m raid1 /dev/sdd1 /dev/sde1

	mkdir /mnt/raidbtrfs

	echo "$(blkid | awk '/sdd1/ { print $2 }') /mnt/raidbtrfs btrfs defaults,nodatasum,device=/dev/sdd1 0 2" >> /etc/fstab

	mount -o nodatasum,device=/dev/sdd1 /dev/sdd1 /mnt/raidbtrfs

	dd if=/dev/urandom of=/mnt/raidbtrfs/100Mfile bs=1M count=100

	mkdir -p /mnt/raidbtrfs/indir1/indir2
	i=1
	while [ $i -lt 101 ]
			do
					dd if=/dev/urandom of=/mnt/raidbtrfs/indir1/indir2/$i-10Kfile bs=10K count=1
					i=$[$i+1]
			done

#########################################################

	parted -s /dev/sdf mklabel msdos mkpart primary 2048s 100% set 1 lvm on
	parted -s /dev/sdg mklabel msdos mkpart primary 2048s 100% set 1 lvm on

	pvcreate /dev/sd[fg]1

	vgcreate lvm /dev/sd[fg]1

	lvcreate --name lvmbtrfs --size 3.9G lvm

	mkfs.btrfs /dev/lvm/lvmbtrfs

	mkdir /mnt/lvmbtrfs

	echo "$(blkid | awk '/lvmbtrfs/ { print $2 }') /mnt/lvmbtrfs btrfs defaults,nodatasum,device=/dev/lvm/lvmbtrfs 0 2" >> /etc/fstab

	mount -o nodatasum,device=/dev/lvm/lvmbtrfs /dev/lvm/lvmbtrfs /mnt/lvmbtrfs

	dd if=/dev/urandom of=/mnt/lvmbtrfs/100Mfile bs=1M count=100

	mkdir -p /mnt/lvmbtrfs/indir1/indir2
	i=1
	while [ $i -lt 101 ]
			do
					dd if=/dev/urandom of=/mnt/lvmbtrfs/indir1/indir2/$i-10Kfile bs=10K count=1
					i=$[$i+1]
			done

#########################################################

	parted -s /dev/sdh mklabel msdos mkpart primary 2048s 100% set 1 raid on
	parted -s /dev/sdi mklabel msdos mkpart primary 2048s 100% set 1 raid on
	parted -s /dev/sdj mklabel msdos mkpart primary 2048s 100% set 1 raid on

	mdadm --create /dev/md127 --verbose --level=raid5 --raid-devices=3 /dev/sdh1 /dev/sdi1 /dev/sdj1

	mkfs.btrfs /dev/md127

	mkdir /mnt/raid5

	echo "$(blkid | awk '/md127/ { print $2 }') /mnt/raid5 btrfs defaults,nodatasum,device=/dev/md127 0 2" >> /etc/fstab

	mount -o nodatasum,device=/dev/md127 /dev/md127 /mnt/raid5

	dd if=/dev/urandom of=/mnt/raid5/100Mfile bs=1M count=100

	mkdir -p /mnt/raid5/indir1/indir2
	i=1
	while [ $i -lt 101 ]
			do
					dd if=/dev/urandom of=/mnt/raid5/indir1/indir2/$i-10Kfile bs=10K count=1
					i=$[$i+1]
			done










