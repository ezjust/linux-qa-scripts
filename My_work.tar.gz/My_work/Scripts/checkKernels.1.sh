#!/bin/bash
vendor="rhel"
function do_setup_RHEL {
	installer="yum"
	install_opts="install"
	uninstall_opts="remove"
	yes_opt="-y"

	local_installer="rpm"
	local_installer_opts="--upgrade --replacepkgs --replacefiles"
	local_downgrade="$local_installer_opts --oldpackage"
	local_yes=""

	extention="rpm"
	dependencies=$deps_redhat
	case "`sed 's/^.*release //' </etc/redhat-release`" in
	  7*) 
		distro_ver=7;
		systemctl status firewalld.service > /dev/null
		if [ "$?" = "0" ]; then
			firewall_configuration_provider="firewall-cmd"
			default_firewall_zone=`firewall-cmd --get-default-zone`
		else
			dependencies="$dependencies lokkit"
			firewall_configuration_provider="lokkit"			
		fi
		;;
	  6*)   distro_ver=6 
		;;
	  5*)
		dependencies=`echo "$dependencies" | sed 's/libblkid//g'` 
		distro_ver=5
		;;
	  *) exit_with_error "Unsupported version of RHEL" ;;
	esac

	packages_tpl="_dir_nbd-dkms*._ext_ $packages_tpl"

	vendor=rhel
}

function is_installed {
	local _package="$1"
	case $vendor in
	  sles|rhel) [ "`rpm -qa | grep -x "$_package"`" ] ;;
	  ubuntu)    [ "`dpkg --list | awk '{ print $2 }' | grep -x $_package`" ] ;;
	  *) echo "ERROR: is_installed $1 : unknown vendor $vendor" ;;
	esac
	return $?
}

function is_available {
	local _package="$1"
	case $vendor in
	  sles) # parse e.g. "kernel-syms-3.7.10-1.1" into "kernel-syms 3.7.10-1.1"
		_pkgname=`echo "$_package" | sed 's/^\([-A-Za-z]*\)-.*$/\1/'`
		_pkgver=`echo "$_package" | sed "s/${_pkgname}-\(.*\)$/\1/"`
		zypper search -s $_pkgname | grep -w $_pkgver
		;;
	  rhel) yum info $_package ;;
	  ubuntu) apt-cache show $_package ;;
	esac >/dev/null 2>/dev/null
	return $?
}

function installed_kernel_names_sles {
	local _versions_to_use="$1"
	kernel_names=""
	IFS=$'\n' all_available_kernels=`$installer wp kernel | grep kernel`
	for kernel in $all_available_kernels; do
		name=`echo $kernel | cut -d '|' -f2 | grep -o "[a-zA-Z0-9\-]\+"`
		version=`echo $kernel | cut -d '|' -f4 | grep -o "[0-9\.\-]\+"`
		[ "`echo "$_versions_to_use" | grep "$version"`" ] && is_installed "$name-$version" &&
		{
			first_file=`rpmquery --filesbypkg $name-$version | grep "/lib/modules/" | head -1`
			kernel_folder_name=`echo $first_file | cut -d '/' -f4`
			kernel_names="$kernel_names $kernel_folder_name"
		}
	done
	echo $kernel_names
}

function installed_kernel_versions {
	case $vendor in
	  sles)
		# TODO: zypper's multiple kernel versions feature (it is not turned on by default)
		#  you still can install required headers manually if you use it
		local unamever=`uname -r`
		flavor=${unamever##*-}
		rpm -qa | grep "^kernel-$flavor-[0-9]" | sed "s/kernel-$flavor-//"
		;;
	  rhel)
		rpm -qa | grep "^\(vz\)*kernel-[0-9]" | sed 's/^.*kernel-//'
		;;
	  ubuntu)
		dpkg --list | grep "^ii.*linux-image-[0-9]" | awk '{ gsub("linux-image-", "", $2); print $2 }'
		;;
	esac
}

function kernel_headers_package_for_version {
	local _kernver="$1"
	case $vendor in
	  sles) echo "kernel-syms-$_kernver" ;;
	  rhel) # it may be 'vzkernel-devel' too, just insert 'devel' after '*kernel':
		rpm -qa | grep "kernel-$_kernver" | sed 's/\(^.*kernel-\)\(.*\)$/\1devel-\2/' ;; 
	  ubuntu) echo "linux-headers-$_kernver" ;;
	esac
}

function matches_running_kernel {
	local _kernver=$1
	case $vendor in
	  sles)
		local unamever=`uname -r`
		local running=${unamever%-*}
		# `uname -r` format on SLES differs from version output of Zypper
		expr match "$_kernver" "$running.*" >/dev/null
		;;
	  ubuntu|rhel)
		[ "`uname -r`" == "$_kernver" ] ;;
	esac
	return $?
}

function additional_kernel_packages {
	case $vendor in
	  # kernel-headers for the running kernel:
	  rhel) rpm -qa | grep "kernel-`uname -r`" | sed 's/\(^.*kernel-\)\(.*\)$/\1headers-\2/' ;; 
	  sles) echo $zypper_oldpackage ;;
	esac
}

function do_determine_kernel_headers {
	kernel_versions="`installed_kernel_versions`" || return $?
	kernel_versions_to_install_modules=""
	kernel_dependencies=''
	absent_kernel_headers=''
	for _kernver in $kernel_versions ; do
		headers_package=`kernel_headers_package_for_version $_kernver`
		is_installed "$headers_package" || {
			if is_available "$headers_package"; then
				kernel_dependencies="$kernel_dependencies $headers_package"
			elif matches_running_kernel $_kernver ; then
				exit_with_error "$headers_package is not available for the running kernel, run with a newer kernel"
			else
				absent_kernel_headers="$absent_kernel_headers $_kernver"
			fi
			continue
		}
		kernel_versions_to_install_modules="$kernel_versions_to_install_modules $_kernver"
	done
	dependencies="`additional_kernel_packages` $dependencies $kernel_dependencies"
	echo "Additional kernel packages to be installed : $kernel_dependencies"	
}

do_setup_RHEL 
do_determine_kernel_headers
echo "$kernel_versions_to_install_modules"
